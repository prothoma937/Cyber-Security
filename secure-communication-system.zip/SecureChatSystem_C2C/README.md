# 🔐 Secure Chat System v2.0
### WhatsApp-style Encrypted Messaging | Data Communication Course Project

---

## Architecture

```
┌─────────────┐        TCP + DH + AES-GCM        ┌─────────────┐
│  ChatClient │ ◄────────────────────────────────► │             │
│  (Alice)    │                                    │  ChatServer │
├─────────────┤                                    │  (Relay)    │
│  ChatClient │ ◄────────────────────────────────► │             │
│  (Bob)      │                                    └─────────────┘
├─────────────┤
│  ChatClient │ ◄─── Each client has its own DH key exchange
│  (Charlie)  │      and unique AES-GCM session key with server
└─────────────┘
```

## Security Features

| Feature              | Detail                                    |
|----------------------|-------------------------------------------|
| Key Exchange         | Diffie-Hellman (2048-bit, RFC 3526 Grp14) |
| Message Encryption   | AES-128-GCM (authenticated encryption)    |
| Key Derivation       | SHA-256 KDF on DH shared secret           |
| IV                   | 96-bit random per message                 |
| Auth Tag             | 128-bit GCM tag (tamper detection)        |
| Key Fingerprint      | First 8 bytes of SHA-256(session key)     |

## Running the Project

### Option A: Compile & Run with Maven

```bash
# 1. Compile
cd SecureChatSystem
mvn compile

# 2. Run Server (in one terminal)
mvn exec:java -Dexec.mainClass="com.mycompany.securechat.ChatServer"

# 3. Run Client (in another terminal — repeat for multiple clients)
mvn exec:java -Dexec.mainClass="com.mycompany.securechat.ChatClient"
```

### Option B: Run with javac directly

```bash
# Compile all files
javac -d out src/main/java/com/mycompany/securechat/*.java

# Run Server
java -cp out com.mycompany.securechat.ChatServer

# Run Client (in separate terminals)
java -cp out com.mycompany.securechat.ChatClient
java -cp out com.mycompany.securechat.ChatClient
java -cp out com.mycompany.securechat.ChatClient
```

### Option C: NetBeans (Original IDE)

1. Open as Maven project
2. Right-click project → Properties → Run → Set Main Class
3. For **Server**: `com.mycompany.securechat.ChatServer`
4. For **Client**: `com.mycompany.securechat.ChatClient`
5. Use "Run" for server, then "Run File" on ChatClient.java for each client

---

## How to Use

### Step 1 — Start the Server
- Open **ChatServer**
- Enter port (default: **5000**)
- Click **▶ Start**
- Server window shows connected clients and logs

### Step 2 — Connect Clients
- Open **ChatClient** (open multiple windows!)
- Enter: Server IP (`127.0.0.1` for same machine), Port, Username
- Click **Connect & Join**
- Key fingerprint is shown — verify it matches server log

### Step 3 — Chat!
- **Group Message**: Type in the input box → Send (goes to everyone)
- **Private Message**: Click a username in the right panel → type → Send
- **Go back to group**: Click "Clear PM / Group" button

---

## Protocol Reference

```
Client → Server:
  JOIN:<username>           Login with username
  PUB:<base64>              DH public key
  MSG:<iv:ct>               Encrypted broadcast message
  PMSG:<to>|<iv:ct>         Encrypted private message
  PING                      Keepalive
  BYE                       Disconnect

Server → Client:
  PUB:<base64>              Server's DH public key
  INFO:<text>               System notification
  ERR:<text>                Error message
  USERS:<u1,u2,...>         Online user list
  JOINED:<username>         Someone joined
  LEFT:<username>           Someone left
  MSG:<from>|<iv:ct>        Encrypted broadcast
  PMSG:<from>|<iv:ct>       Encrypted private message
  PONG                      Keepalive response
```

---

## Files

```
SecureChatSystem/
├── pom.xml
└── src/main/java/com/mycompany/securechat/
    ├── ChatServer.java    ← Central relay server (multi-client)
    ├── ChatClient.java    ← WhatsApp-style GUI client
    └── CryptoUtils.java   ← DH + AES-GCM crypto library
```

---

*Course: Data Communication | Project: Secure Communication System v2.0*
