@echo off
REM ─── Windows Build Script for SecureChat ───
set SRC=src\main\java\com\mycompany\securechat
set OUT=out

mkdir %OUT% 2>nul

echo [1/2] Compiling...
javac -d %OUT% %SRC%\CryptoUtils.java %SRC%\ChatServer.java %SRC%\ChatClient.java
if errorlevel 1 ( echo COMPILE FAILED & pause & exit /b 1 )

echo [2/2] Creating JARs...
jar cfe SecureChatServer.jar com.mycompany.securechat.ChatServer -C %OUT% .
jar cfe SecureChatClient.jar com.mycompany.securechat.ChatClient -C %OUT% .

echo.
echo ✅  Build successful!
echo    Run Server:  java -jar SecureChatServer.jar
echo    Run Client:  java -jar SecureChatClient.jar
pause
