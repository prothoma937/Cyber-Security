package com.mycompany.securechat;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.security.KeyPair;
import java.security.PublicKey;
import javax.crypto.SecretKey;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/**
 * ChatServer — E2E Relay.
 *
 * Transport layer  : each client ↔ server does DH → AES-GCM transport
 * E2E private chat : clients exchange DH public keys THROUGH the server,
 *                    compute shared secret themselves.
 *                    Server relays PMSG opaquely — cannot decrypt.
 *
 * Protocol (all client↔server traffic wrapped in ENC: transport layer):
 *   Client sends (decrypted inner):
 *     MSG:<plaintext>            broadcast
 *     PMSG:<to>|<e2e-cipher>     private (E2E, server-opaque)
 *     C2C_PUB:<peer>|<b64-pub>   DH pub key to relay to peer
 *
 *   Server sends (ENC-wrapped to client):
 *     MSG:<from>|<plaintext>     broadcast relay
 *     PMSG:<from>|<e2e-cipher>   private relay (opaque)
 *     C2C_PUB:<from>|<b64-pub>  relay peer's DH pub
 *     JOINED/LEFT/USERS/INFO/ERR
 */
public class ChatServer extends JFrame {

    private JTextField portField;
    private JButton    startBtn, stopBtn;
    private JTextArea  logArea;
    private JLabel     statusLabel, clientCountLabel;
    private DefaultListModel<String> userListModel;
    private JList<String>            userList;

    private volatile ServerSocket serverSocket;
    private volatile boolean      running = false;
    private final ConcurrentHashMap<String, ClientHandler> clients = new ConcurrentHashMap<>();
    private static final SimpleDateFormat TIME_FMT = new SimpleDateFormat("HH:mm:ss");

    private static final Color BG_DARK   = new Color(18,  18,  18);
    private static final Color BG_PANEL  = new Color(28,  28,  35);
    private static final Color BG_INPUT  = new Color(38,  38,  50);
    private static final Color ACCENT    = new Color(79, 193, 120);
    private static final Color ACCENT2   = new Color(100, 149, 237);
    private static final Color TEXT_MAIN = new Color(230, 230, 235);
    private static final Color TEXT_DIM  = new Color(140, 140, 155);
    private static final Color RED_SOFT  = new Color(220,  80,  80);

    public ChatServer() {
        super("🔐 Secure Chat — Server [E2E]");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buildUI();
        setSize(900, 650);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        JPanel topBar = new JPanel(new BorderLayout(12, 0));
        topBar.setBackground(BG_PANEL);
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        JLabel title = new JLabel("🔐 SecureChat Server  [Client-to-Client E2E DH]");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(ACCENT);
        topBar.add(title, BorderLayout.WEST);
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        controls.setOpaque(false);
        controls.add(label("Port:", TEXT_DIM));
        portField = new JTextField("5000", 6);
        portField.setFont(new Font("Consolas", Font.PLAIN, 13));
        portField.setBackground(BG_INPUT); portField.setForeground(TEXT_MAIN);
        portField.setCaretColor(ACCENT);
        portField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 90), 1),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        controls.add(portField);
        startBtn = makeBtn("▶ Start", ACCENT, Color.BLACK);
        stopBtn  = makeBtn("■ Stop",  RED_SOFT, Color.WHITE);
        stopBtn.setEnabled(false);
        controls.add(startBtn); controls.add(stopBtn);
        topBar.add(controls, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        statusBar.setBackground(new Color(22, 22, 30));
        statusBar.setBorder(BorderFactory.createEmptyBorder(2, 10, 2, 10));
        statusLabel      = label("● Stopped", RED_SOFT);
        clientCountLabel = label("Clients: 0", TEXT_DIM);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statusBar.add(statusLabel);
        statusBar.add(label(" | ", TEXT_DIM));
        statusBar.add(clientCountLabel);
        JLabel note = label("  ⚡ Private messages: E2E encrypted — server cannot read", new Color(100,200,140));
        note.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        statusBar.add(note);
        add(statusBar, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setDividerLocation(640); split.setDividerSize(3); split.setBorder(null);
        logArea = new JTextArea();
        logArea.setEditable(false); logArea.setBackground(BG_DARK); logArea.setForeground(TEXT_MAIN);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setLineWrap(true); logArea.setWrapStyleWord(true);
        logArea.setMargin(new Insets(8, 10, 8, 10));
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(null); logScroll.getViewport().setBackground(BG_DARK);
        split.setLeftComponent(logScroll);
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(BG_PANEL);
        JLabel onlineLabel = new JLabel("  👥 Online Users");
        onlineLabel.setFont(new Font("Segoe UI", Font.BOLD, 13)); onlineLabel.setForeground(ACCENT2);
        onlineLabel.setBorder(BorderFactory.createEmptyBorder(10, 8, 8, 8));
        rightPanel.add(onlineLabel, BorderLayout.NORTH);
        userListModel = new DefaultListModel<>();
        userList = new JList<>(userListModel);
        userList.setBackground(BG_PANEL); userList.setForeground(TEXT_MAIN);
        userList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        userList.setSelectionBackground(new Color(60, 60, 80));
        userList.setCellRenderer(new UserCellRenderer());
        JScrollPane userScroll = new JScrollPane(userList);
        userScroll.setBorder(null); userScroll.getViewport().setBackground(BG_PANEL);
        rightPanel.add(userScroll, BorderLayout.CENTER);
        split.setRightComponent(rightPanel);
        add(split, BorderLayout.CENTER);
        startBtn.addActionListener(e -> startServer());
        stopBtn.addActionListener(e -> stopServer());
    }

    private void startServer() {
        startBtn.setEnabled(false); portField.setEditable(false); running = true;
        new Thread(() -> {
            try {
                int port = Integer.parseInt(portField.getText().trim());
                serverSocket = new ServerSocket(port);
                serverSocket.setReuseAddress(true);
                SwingUtilities.invokeLater(() -> {
                    statusLabel.setText("● Running on port " + port);
                    statusLabel.setForeground(ACCENT);
                    stopBtn.setEnabled(true);
                });
                log("Server started on port " + port + "  [Client-to-Client E2E DH Mode]");
                log("Private messages are relayed opaquely — server cannot decrypt them.\n");
                while (running) {
                    try {
                        Socket sock = serverSocket.accept();
                        new Thread(new ClientHandler(sock), "Client-" + sock.getRemoteSocketAddress()).start();
                    } catch (SocketException ignored) {}
                }
            } catch (Exception ex) { log("ERROR: " + ex.getMessage()); stopServer(); }
        }, "Server-Accept").start();
    }

    private void stopServer() {
        running = false;
        try { if (serverSocket != null && !serverSocket.isClosed()) serverSocket.close(); } catch (IOException ignored) {}
        for (ClientHandler h : clients.values()) h.disconnect("Server shutting down");
        clients.clear();
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText("● Stopped"); statusLabel.setForeground(RED_SOFT);
            startBtn.setEnabled(true); stopBtn.setEnabled(false);
            portField.setEditable(true); userListModel.clear();
            clientCountLabel.setText("Clients: 0");
        });
        log("\nServer stopped.");
    }

    // ── Relay helpers ──────────────────────────────────────────────────────────

    /** Wrap plaintext in this client's transport encryption and send */
    void sendEncrypted(ClientHandler target, String plain) {
        try {
            String enc = CryptoUtils.encryptAESGCM(plain, target.transportKey);
            target.sendRaw("ENC:" + enc);
        } catch (Exception ex) {
            log("Transport encrypt error → " + target.username + ": " + ex.getMessage());
        }
    }

    void broadcastEncrypted(String plain, String excludeUser) {
        for (Map.Entry<String, ClientHandler> e : clients.entrySet())
            if (!e.getKey().equals(excludeUser)) sendEncrypted(e.getValue(), plain);
    }

    /** Relay a PMSG opaquely — server never touches the inner payload */
    void relayPrivate(String from, String to, String opaquePayload) {
        ClientHandler target = clients.get(to);
        if (target == null) {
            ClientHandler sender = clients.get(from);
            if (sender != null) sendEncrypted(sender, "ERR:User '" + to + "' is not online.");
            return;
        }
        sendEncrypted(target, "PMSG:" + from + "|" + opaquePayload);
    }

    void sendUserList(ClientHandler target) {
        sendEncrypted(target, "USERS:" + String.join(",", clients.keySet()));
    }

    void sendUserListToAll() {
        String list = String.join(",", clients.keySet());
        for (ClientHandler h : clients.values()) sendEncrypted(h, "USERS:" + list);
    }

    void updateClientCountUI() {
        SwingUtilities.invokeLater(() -> {
            clientCountLabel.setText("Clients: " + clients.size());
            userListModel.clear();
            for (String u : clients.keySet()) userListModel.addElement(u);
        });
    }

    void log(String msg) {
        String ts = "[" + TIME_FMT.format(new Date()) + "] ";
        SwingUtilities.invokeLater(() -> {
            logArea.append(ts + msg + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }

    // ── Client Handler ─────────────────────────────────────────────────────────
    class ClientHandler implements Runnable {
        final Socket socket;
        DataInputStream  in;
        DataOutputStream out;
        String    username     = null;
        SecretKey transportKey = null;
        KeyPair   myKeyPair;

        ClientHandler(Socket s) { this.socket = s; }

        @Override
        public void run() {
            try {
                in  = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));

                // Step 1: JOIN
                String joinLine = in.readUTF();
                if (!joinLine.startsWith("JOIN:")) { sendRaw("ERR:Expected JOIN"); closeSocket(); return; }
                username = joinLine.substring(5).trim();
                if (username.isEmpty() || username.length() > 20) { sendRaw("ERR:Invalid username"); closeSocket(); return; }
                if (clients.containsKey(username))                { sendRaw("ERR:Username taken");   closeSocket(); return; }

                // Step 2: Transport DH (client ↔ server)
                myKeyPair = CryptoUtils.generateDHKeyPair();
                String myPub = java.util.Base64.getEncoder()
                        .encodeToString(CryptoUtils.encodePublicKey(myKeyPair.getPublic()));
                sendRaw("PUB:" + myPub);

                String pubLine = in.readUTF();
                if (!pubLine.startsWith("PUB:")) { sendRaw("ERR:Expected PUB"); closeSocket(); return; }
                PublicKey clientPub = CryptoUtils.decodeDHPublicKey(
                        java.util.Base64.getDecoder().decode(pubLine.substring(4)));
                byte[]    shared    = CryptoUtils.agreeSharedSecret(myKeyPair.getPrivate(), clientPub);
                transportKey        = CryptoUtils.deriveAESKey(shared);
                String    fp        = CryptoUtils.shortKeyFingerprint(transportKey);

                // Step 3: Register
                clients.put(username, this);
                log("✓ " + username + " connected  transport-fp=" + fp);
                sendEncrypted(this, "INFO:Welcome " + username + "! Transport secured. fp=" + fp);
                sendUserList(this);
                broadcastEncrypted("JOINED:" + username, username);
                sendUserListToAll();
                updateClientCountUI();

                // Step 4: Message loop
                while (!socket.isClosed()) {
                    String line = in.readUTF();
                    if (line.startsWith("ENC:")) {
                        String inner;
                        try { inner = CryptoUtils.decryptAESGCM(line.substring(4), transportKey); }
                        catch (Exception ex) { log("Decrypt err [" + username + "]: " + ex.getMessage()); continue; }
                        dispatch(inner);
                    } else if (line.equals("PING")) {
                        sendRaw("PONG");
                    } else if (line.equals("BYE")) {
                        break;
                    }
                }
            } catch (EOFException | SocketException ignored) {
            } catch (Exception ex) { log("Handler error [" + username + "]: " + ex.getMessage()); }
            finally { cleanup(); }
        }

        private void dispatch(String inner) {
            if (inner.startsWith("MSG:")) {
                // Group broadcast — server sees plaintext (group is not E2E)
                String text = inner.substring(4);
                log("[GROUP] " + username + ": " + text);
                for (Map.Entry<String, ClientHandler> e : clients.entrySet())
                    if (!e.getKey().equals(username))
                        sendEncrypted(e.getValue(), "MSG:" + username + "|" + text);

            } else if (inner.startsWith("PMSG:")) {
                // Private — E2E payload, server relays opaquely
                String body = inner.substring(5);
                int sep = body.indexOf('|'); if (sep < 0) return;
                String to      = body.substring(0, sep);
                String payload = body.substring(sep + 1);
                log("[PM] " + username + " → " + to + ": <E2E — opaque to server>");
                relayPrivate(username, to, payload);

            } else if (inner.startsWith("C2C_PUB:")) {
                // Client-to-client DH public key relay
                String body = inner.substring(8);
                int sep = body.indexOf('|'); if (sep < 0) return;
                String peer   = body.substring(0, sep);
                String pubB64 = body.substring(sep + 1);
                log("[C2C-DH] relay pub: " + username + " → " + peer);
                ClientHandler target = clients.get(peer);
                if (target == null) { sendEncrypted(this, "ERR:User '" + peer + "' not online."); return; }
                sendEncrypted(target, "C2C_PUB:" + username + "|" + pubB64);

            } else {
                log("[?] " + username + ": " + inner);
            }
        }

        void disconnect(String reason) { sendEncrypted(this, "INFO:" + reason); closeSocket(); }

        void sendRaw(String line) {
            try { synchronized (out) { out.writeUTF(line); out.flush(); } }
            catch (Exception ignored) {}
        }

        void cleanup() {
            if (username != null) {
                clients.remove(username);
                log("✗ " + username + " disconnected");
                broadcastEncrypted("LEFT:" + username, username);
                sendUserListToAll();
                updateClientCountUI();
            }
            closeSocket();
        }

        void closeSocket() { try { socket.close(); } catch (IOException ignored) {} }
    }

    static class UserCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            setText("  🟢 " + value);
            setFont(new Font("Segoe UI", Font.PLAIN, 13));
            setBackground(isSelected ? new Color(60, 60, 80) : new Color(28, 28, 35));
            setForeground(new Color(220, 220, 235));
            setBorder(BorderFactory.createEmptyBorder(5, 4, 5, 4));
            return this;
        }
    }

    private JButton makeBtn(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setBackground(bg); b.setForeground(fg);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        return b;
    }

    private JLabel label(String text, Color color) {
        JLabel l = new JLabel(text); l.setForeground(color);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        return l;
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new ChatServer().setVisible(true));
    }
}
