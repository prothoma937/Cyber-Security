package com.mycompany.securechat;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.security.KeyPair;
import java.security.PublicKey;
import javax.crypto.SecretKey;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ChatClient — Client-to-Client E2E DH secure chat.
 *
 * Two-layer encryption:
 *   Layer 1 (transport)  : this client ↔ server DH → AES-GCM
 *   Layer 2 (E2E)        : this client ↔ peer    DH → AES-GCM
 *
 * Private message fingerprint = hash of the C2C shared secret.
 * Both peers compute the SAME secret → SAME fingerprint.
 * Server cannot decrypt private messages.
 *
 * C2C DH handshake (triggered when opening a private chat):
 *   1. We generate a fresh DH key pair for this peer.
 *   2. Send our pub to server: C2C_PUB:<peer>|<b64>
 *   3. Server relays to peer (wrapped in peer's transport encryption).
 *   4. Peer does the same toward us.
 *   5. Each side computes sharedSecret = DH(myPriv, peerPub).
 *   6. Both derive the same AES key → same FP.
 */
public class ChatClient extends JFrame {

    // Colours
    private static final Color BG_DARK       = new Color(11,  20,  26);
    private static final Color BG_CHAT       = new Color(11,  20,  26);
    private static final Color BG_PANEL      = new Color(22,  33,  42);
    private static final Color BG_TOP        = new Color(31,  44,  56);
    private static final Color BG_INPUT_BAR  = new Color(22,  33,  42);
    private static final Color BG_MSG_SELF   = new Color(0,   92,  75);
    private static final Color BG_MSG_OTHER  = new Color(32,  45,  58);
    private static final Color BG_MSG_PM     = new Color(75,  38, 100);
    private static final Color BG_INPUT      = new Color(42,  57,  69);
    private static final Color BG_SEARCH     = new Color(18,  28,  36);
    private static final Color BG_SIDEBAR    = new Color(18,  27,  35);
    private static final Color BG_CONTACT_SEL= new Color(31,  44,  56);
    private static final Color BG_CONTACT_HOV= new Color(24,  35,  45);
    private static final Color ACCENT_GREEN  = new Color(0,  168, 132);
    private static final Color ACCENT_BLUE   = new Color(100, 149, 237);
    private static final Color ACCENT_TEAL   = new Color(0,  200, 160);
    private static final Color TEXT_MAIN     = new Color(229, 221, 213);
    private static final Color TEXT_DIM      = new Color(140, 150, 158);
    private static final Color TEXT_TIME     = new Color(130, 150, 140);
    private static final Color HIGHLIGHT_CLR = new Color(255, 220,   0, 80);
    private static final Color BADGE_BG      = new Color(0,  168, 132);

    private static final Font FONT_MSG   = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BOLD  = new Font("Segoe UI", Font.BOLD,  14);
    private static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    private static final Font FONT_MONO  = new Font("Consolas",  Font.PLAIN, 11);
    private static final SimpleDateFormat TIME_FMT = new SimpleDateFormat("HH:mm");

    // Login
    private JPanel loginPanel;
    private JTextField loginHost, loginPort, loginUsername;
    private JButton loginBtn;
    private JLabel  loginStatus;

    // Main
    private JPanel    mainPanel, contactListPanel;
    private JScrollPane contactScroll;
    private JPanel    rightArea;
    private CardLayout rightCards;
    private JLabel    topBarName, topBarStatus, fingerprintLabel;

    // ── Per-conversation state ──────────────────────────────────────────────────
    private static class ChatPane {
        final String  key;
        final boolean isGroup;
        JPanel root, messagesPanel;
        JScrollPane chatScroll;
        JTextField  inputField;
        JButton     sendBtn, emojiBtn;
        JPanel      searchBar;
        JTextField  searchField;
        JLabel      searchResultLabel;
        JButton     searchPrevBtn, searchNextBtn;
        final List<BubbleEntry> bubbles       = new ArrayList<>();
        final List<BubbleEntry> searchMatches = new ArrayList<>();
        int searchMatchIndex = -1;
        int unreadCount = 0;
        ChatPane(String k, boolean g) { key=k; isGroup=g; }
    }

    private static class BubbleEntry {
        JPanel row, bubble; String text, from; Color origBg;
        BubbleEntry(JPanel r, JPanel b, String f, String t, Color c){ row=r; bubble=b; from=f; text=t; origBg=c; }
    }

    private static class ContactRow {
        final String key; final boolean isGroup;
        JPanel panel; JLabel nameLabel, lastMsgLabel, badgeLabel;
        int unreadCount = 0;
        ContactRow(String k, boolean g){ key=k; isGroup=g; }
    }

    // ── C2C DH state per peer ───────────────────────────────────────────────────
    /**
     * Holds the state for a single client-to-client DH session.
     * Once both pubs are exchanged, e2eKey != null and both peers
     * show the SAME fingerprint.
     */
    private static class C2CSession {
        KeyPair   myKeyPair;       // Our DH key pair for this peer
        PublicKey peerPublicKey;   // Their DH public key (received via server relay)
        SecretKey e2eKey;          // Derived AES key (null until both pubs exchanged)
        String    fingerprint;     // Displayable FP (same on both ends)
        boolean   sentMyPub = false;

        C2CSession() throws Exception {
            myKeyPair = CryptoUtils.generateDHKeyPair();
        }

        /** Call when peer's pub arrives — derives shared secret if possible */
        void receivePeerPub(PublicKey pub) throws Exception {
            this.peerPublicKey = pub;
            if (sentMyPub) derive();
        }

        void derive() throws Exception {
            byte[] shared = CryptoUtils.agreeSharedSecret(myKeyPair.getPrivate(), peerPublicKey);
            e2eKey      = CryptoUtils.deriveAESKey(shared);
            fingerprint = CryptoUtils.shortKeyFingerprint(e2eKey);
        }

        boolean isReady() { return e2eKey != null; }
    }

    private final Map<String, ChatPane>   chatPanes    = new LinkedHashMap<>();
    private final Map<String, ContactRow> contactRows  = new LinkedHashMap<>();
    // C2C sessions keyed by peer username
    private final ConcurrentHashMap<String, C2CSession> c2cSessions = new ConcurrentHashMap<>();

    private String    activeChatKey = "GROUP";
    private String    myUsername;
    private volatile Socket socket;
    private DataInputStream  in;
    private DataOutputStream out;

    // Transport layer (client ↔ server)
    private KeyPair   transportKeyPair;
    private SecretKey transportKey;
    private String    transportFP;

    private final CardLayout rootCards = new CardLayout();

    public ChatClient() {
        super("SecureChat");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(rootCards);
        buildLoginPanel();
        buildMainPanel();
        add(loginPanel, "login");
        add(mainPanel,  "main");
        setSize(1080, 720);
        setMinimumSize(new Dimension(780, 520));
        setLocationRelativeTo(null);
        rootCards.show(getContentPane(), "login");
    }

    // ── LOGIN ─────────────────────────────────────────────────────────────────
    private void buildLoginPanel() {
        loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(BG_DARK);
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(BG_PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 65, 80), 1),
                BorderFactory.createEmptyBorder(40, 52, 40, 52)));
        card.setMaximumSize(new Dimension(420, 620));

        JLabel logo = new JLabel("🔐", SwingConstants.CENTER);
        logo.setFont(new Font("Segoe UI", Font.PLAIN, 56)); logo.setAlignmentX(CENTER_ALIGNMENT); card.add(logo);
        card.add(Box.createVerticalStrut(6));
        JLabel appName = new JLabel("SecureChat", SwingConstants.CENTER);
        appName.setFont(new Font("Segoe UI", Font.BOLD, 26)); appName.setForeground(ACCENT_GREEN);
        appName.setAlignmentX(CENTER_ALIGNMENT); card.add(appName);
        JLabel sub = new JLabel("Client-to-Client E2E  ·  DH + AES-GCM", SwingConstants.CENTER);
        sub.setFont(FONT_SMALL); sub.setForeground(TEXT_DIM); sub.setAlignmentX(CENTER_ALIGNMENT); card.add(sub);
        card.add(Box.createVerticalStrut(32));
        card.add(lbl("Server IP"));   loginHost     = tf("127.0.0.1"); card.add(loginHost);
        card.add(Box.createVerticalStrut(14));
        card.add(lbl("Port"));        loginPort     = tf("5000");      card.add(loginPort);
        card.add(Box.createVerticalStrut(14));
        card.add(lbl("Username"));    loginUsername = tf("");          card.add(loginUsername);
        card.add(Box.createVerticalStrut(26));
        loginBtn = new JButton("Connect & Join");
        loginBtn.setAlignmentX(CENTER_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        styleBtn(loginBtn, ACCENT_GREEN, Color.BLACK); card.add(loginBtn);
        card.add(Box.createVerticalStrut(12));
        loginStatus = new JLabel(" ", SwingConstants.CENTER);
        loginStatus.setFont(FONT_SMALL); loginStatus.setForeground(new Color(220, 80, 80));
        loginStatus.setAlignmentX(CENTER_ALIGNMENT); card.add(loginStatus);
        loginBtn.addActionListener(e -> doConnect());
        loginUsername.addActionListener(e -> doConnect());
        loginPanel.add(card, new GridBagConstraints());
    }

    // ── MAIN PANEL ────────────────────────────────────────────────────────────
    private void buildMainPanel() {
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_DARK);
        mainPanel.add(buildTopBar(), BorderLayout.NORTH);
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(BG_SIDEBAR); sidebar.setPreferredSize(new Dimension(290, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(30, 45, 58)));
        JPanel sideTop = new JPanel(new BorderLayout()); sideTop.setBackground(BG_TOP);
        sideTop.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JLabel t = new JLabel("💬  Chats"); t.setFont(FONT_BOLD); t.setForeground(ACCENT_BLUE);
        sideTop.add(t, BorderLayout.WEST); sidebar.add(sideTop, BorderLayout.NORTH);
        contactListPanel = new JPanel();
        contactListPanel.setLayout(new BoxLayout(contactListPanel, BoxLayout.Y_AXIS));
        contactListPanel.setBackground(BG_SIDEBAR);
        contactScroll = new JScrollPane(contactListPanel);
        contactScroll.setBorder(null); contactScroll.getViewport().setBackground(BG_SIDEBAR);
        contactScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sidebar.add(contactScroll, BorderLayout.CENTER);
        JLabel hint = new JLabel("<html><center>Click a contact to chat</center></html>", SwingConstants.CENTER);
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 10)); hint.setForeground(TEXT_DIM);
        hint.setBorder(BorderFactory.createEmptyBorder(6, 4, 8, 4)); sidebar.add(hint, BorderLayout.SOUTH);
        rightCards = new CardLayout();
        rightArea  = new JPanel(rightCards); rightArea.setBackground(BG_DARK);
        JPanel ph = new JPanel(new GridBagLayout()); ph.setBackground(BG_DARK);
        JLabel phl = new JLabel("Select a chat to start messaging");
        phl.setForeground(TEXT_DIM); phl.setFont(FONT_BOLD); ph.add(phl);
        rightArea.add(ph, "_placeholder_");
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebar, rightArea);
        split.setDividerLocation(290); split.setDividerSize(2); split.setBorder(null);
        mainPanel.add(split, BorderLayout.CENTER);
    }

    private JPanel buildTopBar() {
        JPanel topBar = new JPanel(new BorderLayout(10, 0));
        topBar.setBackground(BG_TOP);
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 12));
        JPanel topLeft = new JPanel(new BorderLayout(0, 3)); topLeft.setOpaque(false);
        JLabel avatar = new JLabel("🔐"); avatar.setFont(new Font("Segoe UI", Font.PLAIN, 26));
        topLeft.add(avatar, BorderLayout.WEST);
        JPanel tlt = new JPanel(new BorderLayout(0, 2)); tlt.setOpaque(false);
        tlt.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        topBarName   = new JLabel("SecureChat"); topBarName.setFont(FONT_BOLD); topBarName.setForeground(TEXT_MAIN);
        topBarStatus = new JLabel("Not connected"); topBarStatus.setFont(FONT_SMALL); topBarStatus.setForeground(TEXT_DIM);
        tlt.add(topBarName, BorderLayout.NORTH); tlt.add(topBarStatus, BorderLayout.SOUTH);
        topLeft.add(tlt, BorderLayout.CENTER); topBar.add(topLeft, BorderLayout.WEST);
        fingerprintLabel = new JLabel("🔑 transport-fp: --------");
        fingerprintLabel.setFont(FONT_MONO); fingerprintLabel.setForeground(TEXT_DIM);
        fingerprintLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topBar.add(fingerprintLabel, BorderLayout.CENTER);
        JPanel topRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0)); topRight.setOpaque(false);
        JButton disconnectBtn = new JButton("✕ Disconnect");
        styleBtn(disconnectBtn, new Color(200, 70, 70), Color.WHITE);
        disconnectBtn.addActionListener(e -> doDisconnect());
        topRight.add(disconnectBtn); topBar.add(topRight, BorderLayout.EAST);
        return topBar;
    }

    // ── CHAT PANE ─────────────────────────────────────────────────────────────
    private ChatPane createChatPane(String key, boolean isGroup) {
        ChatPane cp = new ChatPane(key, isGroup);
        cp.root = new JPanel(new BorderLayout()); cp.root.setBackground(BG_CHAT);
        JPanel chatHeader = new JPanel(new BorderLayout(8, 0));
        chatHeader.setBackground(BG_PANEL);
        chatHeader.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        JLabel chatIcon = new JLabel(isGroup ? "👥" : "👤");
        chatIcon.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        JPanel headerInfo = new JPanel(new BorderLayout(0, 2)); headerInfo.setOpaque(false);
        JLabel chatName = new JLabel(isGroup ? "Group Chat" : key);
        chatName.setFont(FONT_BOLD); chatName.setForeground(TEXT_MAIN);
        String subText = isGroup ? "All members" : "Private · End-to-End Encrypted";
        JLabel chatSub = new JLabel(subText);
        chatSub.setFont(FONT_SMALL); chatSub.setForeground(TEXT_DIM);
        headerInfo.add(chatName, BorderLayout.NORTH); headerInfo.add(chatSub, BorderLayout.SOUTH);
        chatHeader.add(chatIcon, BorderLayout.WEST);
        chatHeader.add(headerInfo, BorderLayout.CENTER);
        JButton srchBtn = mkBtn2("🔍"); srchBtn.setToolTipText("Search messages (Ctrl+F)");
        chatHeader.add(srchBtn, BorderLayout.EAST);
        cp.root.add(chatHeader, BorderLayout.NORTH);
        cp.messagesPanel = new JPanel();
        cp.messagesPanel.setLayout(new BoxLayout(cp.messagesPanel, BoxLayout.Y_AXIS));
        cp.messagesPanel.setBackground(BG_CHAT);
        cp.messagesPanel.setBorder(BorderFactory.createEmptyBorder(12, 0, 12, 0));
        cp.chatScroll = new JScrollPane(cp.messagesPanel);
        cp.chatScroll.setBorder(null); cp.chatScroll.getViewport().setBackground(BG_CHAT);
        cp.chatScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        cp.chatScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cp.chatScroll.getVerticalScrollBar().setUnitIncrement(20);
        cp.searchBar = buildSearchBarFor(cp); cp.searchBar.setVisible(false);
        JPanel centerArea = new JPanel(new BorderLayout()); centerArea.setBackground(BG_CHAT);
        centerArea.add(cp.searchBar, BorderLayout.NORTH);
        centerArea.add(cp.chatScroll, BorderLayout.CENTER);
        cp.root.add(centerArea, BorderLayout.CENTER);
        cp.root.add(buildInputBarFor(cp), BorderLayout.SOUTH);
        srchBtn.addActionListener(e -> toggleSearch(cp));
        rightArea.add(cp.root, key);
        chatPanes.put(key, cp);
        return cp;
    }

    private JPanel buildSearchBarFor(ChatPane cp) {
        JPanel bar = new JPanel(new BorderLayout(6, 0));
        bar.setBackground(BG_SEARCH);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(50, 70, 85)),
                BorderFactory.createEmptyBorder(8, 14, 8, 10)));
        cp.searchField = new JTextField();
        cp.searchField.setBackground(BG_INPUT); cp.searchField.setForeground(TEXT_MAIN);
        cp.searchField.setCaretColor(ACCENT_GREEN); cp.searchField.setFont(FONT_MSG);
        cp.searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 80, 95), 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        cp.searchResultLabel = new JLabel("  Type to search...");
        cp.searchResultLabel.setFont(FONT_SMALL); cp.searchResultLabel.setForeground(TEXT_DIM);
        cp.searchResultLabel.setPreferredSize(new Dimension(160, 24));
        cp.searchPrevBtn = mkBtn2("▲"); cp.searchNextBtn = mkBtn2("▼");
        JButton closeBtn = mkBtn2("✕");
        closeBtn.addActionListener(e -> toggleSearch(cp));
        cp.searchPrevBtn.addActionListener(e -> navSearch(cp, -1));
        cp.searchNextBtn.addActionListener(e -> navSearch(cp, 1));
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0)); nav.setOpaque(false);
        nav.add(cp.searchResultLabel); nav.add(cp.searchPrevBtn); nav.add(cp.searchNextBtn); nav.add(closeBtn);
        JLabel icon = new JLabel("🔍 "); icon.setForeground(TEXT_DIM);
        bar.add(icon, BorderLayout.WEST); bar.add(cp.searchField, BorderLayout.CENTER); bar.add(nav, BorderLayout.EAST);
        cp.searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){
            public void insertUpdate(javax.swing.event.DocumentEvent e){ doSearch(cp); }
            public void removeUpdate(javax.swing.event.DocumentEvent e){ doSearch(cp); }
            public void changedUpdate(javax.swing.event.DocumentEvent e){ doSearch(cp); }
        });
        cp.searchField.addActionListener(e -> navSearch(cp, 1));
        return bar;
    }

    private JPanel buildInputBarFor(ChatPane cp) {
        JPanel bar = new JPanel(new BorderLayout(6, 0));
        bar.setBackground(BG_INPUT_BAR);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(40, 58, 72)),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        JPanel inputRow = new JPanel(new BorderLayout(6, 0)); inputRow.setOpaque(false);
        cp.emojiBtn = new JButton("😊");
        cp.emojiBtn.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        cp.emojiBtn.setBackground(BG_INPUT); cp.emojiBtn.setForeground(TEXT_MAIN);
        cp.emojiBtn.setFocusPainted(false); cp.emojiBtn.setBorderPainted(false);
        cp.emojiBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cp.emojiBtn.setPreferredSize(new Dimension(42, 42));
        cp.inputField = new JTextField();
        cp.inputField.setBackground(BG_INPUT); cp.inputField.setForeground(TEXT_MAIN);
        cp.inputField.setCaretColor(ACCENT_GREEN); cp.inputField.setFont(FONT_MSG);
        cp.inputField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 80, 95), 1),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        cp.inputField.setEnabled(false);
        cp.sendBtn = new JButton("  ➤  Send");
        cp.sendBtn.setEnabled(false); cp.sendBtn.setPreferredSize(new Dimension(110, 42));
        styleBtn(cp.sendBtn, ACCENT_TEAL, Color.BLACK);
        inputRow.add(cp.emojiBtn, BorderLayout.WEST);
        inputRow.add(cp.inputField, BorderLayout.CENTER);
        inputRow.add(cp.sendBtn, BorderLayout.EAST);
        bar.add(inputRow, BorderLayout.CENTER);
        cp.sendBtn.addActionListener(e -> doSend(cp));
        cp.inputField.addActionListener(e -> doSend(cp));
        cp.emojiBtn.addActionListener(e -> showEmoji(cp));
        cp.inputField.getInputMap().put(KeyStroke.getKeyStroke("ctrl F"), "search");
        cp.inputField.getActionMap().put("search", new AbstractAction(){
            public void actionPerformed(ActionEvent e){ toggleSearch(cp); }
        });
        return bar;
    }

    // ── CONTACT ROW ───────────────────────────────────────────────────────────
    private ContactRow createContactRow(String key, boolean isGroup) {
        ContactRow cr = new ContactRow(key, isGroup);
        cr.panel = new JPanel(new BorderLayout(12, 0));
        cr.panel.setBackground(BG_SIDEBAR);
        cr.panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 68));
        cr.panel.setPreferredSize(new Dimension(290, 68));
        cr.panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(28, 40, 52)),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        JLabel ava = new JLabel(isGroup ? "👥" : "👤");
        ava.setFont(new Font("Segoe UI", Font.PLAIN, 26)); cr.panel.add(ava, BorderLayout.WEST);
        JPanel mid = new JPanel(new BorderLayout(0, 3)); mid.setOpaque(false);
        cr.nameLabel = new JLabel(isGroup ? "Group Chat" : key);
        cr.nameLabel.setFont(FONT_BOLD); cr.nameLabel.setForeground(TEXT_MAIN);
        cr.lastMsgLabel = new JLabel(isGroup ? "All members" : "Private message");
        cr.lastMsgLabel.setFont(FONT_SMALL); cr.lastMsgLabel.setForeground(TEXT_DIM);
        mid.add(cr.nameLabel, BorderLayout.NORTH); mid.add(cr.lastMsgLabel, BorderLayout.SOUTH);
        cr.panel.add(mid, BorderLayout.CENTER);
        JPanel badgePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); badgePanel.setOpaque(false);
        cr.badgeLabel = new JLabel("0");
        cr.badgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 10));
        cr.badgeLabel.setForeground(Color.WHITE); cr.badgeLabel.setBackground(BADGE_BG); cr.badgeLabel.setOpaque(true);
        cr.badgeLabel.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
        cr.badgeLabel.setVisible(false);
        badgePanel.add(cr.badgeLabel); cr.panel.add(badgePanel, BorderLayout.EAST);
        cr.panel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){ if(!key.equals(activeChatKey)) cr.panel.setBackground(BG_CONTACT_HOV); }
            public void mouseExited(MouseEvent e) { if(!key.equals(activeChatKey)) cr.panel.setBackground(BG_SIDEBAR); }
            public void mouseClicked(MouseEvent e){ switchToChat(key); }
        });
        contactListPanel.add(cr.panel);
        contactListPanel.revalidate(); contactListPanel.repaint();
        contactRows.put(key, cr);
        return cr;
    }

    private void switchToChat(String key) {
        ContactRow oldCr = contactRows.get(activeChatKey);
        if (oldCr != null) oldCr.panel.setBackground(BG_SIDEBAR);
        activeChatKey = key;
        ContactRow newCr = contactRows.get(key);
        if (newCr != null) {
            newCr.panel.setBackground(BG_CONTACT_SEL);
            newCr.unreadCount = 0; newCr.badgeLabel.setVisible(false);
        }
        ChatPane cp = chatPanes.get(key);
        if (cp == null) {
            cp = createChatPane(key, "GROUP".equals(key));
            if (transportKey != null) { cp.inputField.setEnabled(true); cp.sendBtn.setEnabled(true); }
        }

        // If switching to a private chat, initiate C2C DH if not done yet
        if (!"GROUP".equals(key)) initiateC2CDH(key, cp);

        rightCards.show(rightArea, key);
        cp.inputField.requestFocus();
        scrollToBottom(cp);
    }

    // ── C2C DH ───────────────────────────────────────────────────────────────

    /** Start C2C DH with peer if no session exists yet */
    private void initiateC2CDH(String peer, ChatPane cp) {
        if (c2cSessions.containsKey(peer)) return;   // already started or complete
        try {
            C2CSession session = new C2CSession();
            c2cSessions.put(peer, session);
            // Send our DH pub to the peer via server relay
            String myPubB64 = Base64.getEncoder().encodeToString(
                    CryptoUtils.encodePublicKey(session.myKeyPair.getPublic()));
            sendEncrypted("C2C_PUB:" + peer + "|" + myPubB64);
            session.sentMyPub = true;
            addSys(cp, "🔄  Initiating E2E key exchange with " + peer + "...");
        } catch (Exception ex) {
            addSys(cp, "❌  C2C DH init error: " + ex.getMessage());
        }
    }

    /** Called when we receive peer's DH pub (C2C_PUB from server) */
    private void onReceivePeerPub(String peer, String pubB64) {
        try {
            PublicKey peerPub = CryptoUtils.decodeDHPublicKey(Base64.getDecoder().decode(pubB64));

            C2CSession session = c2cSessions.get(peer);
            if (session == null) {
                // Peer initiated first — create our session and respond
                session = new C2CSession();
                c2cSessions.put(peer, session);
                // Send our pub back
                String myPubB64 = Base64.getEncoder().encodeToString(
                        CryptoUtils.encodePublicKey(session.myKeyPair.getPublic()));
                sendEncrypted("C2C_PUB:" + peer + "|" + myPubB64);
                session.sentMyPub = true;
            }

            session.receivePeerPub(peerPub);

            if (session.isReady()) {
                final String fp = session.fingerprint;
                SwingUtilities.invokeLater(() -> onC2CSessionReady(peer, fp));
            }
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> addSysToActive("❌  C2C DH error with " + peer + ": " + ex.getMessage()));
        }
    }

    /** Called on EDT when C2C session is established */
    private void onC2CSessionReady(String peer, String fp) {
        ChatPane cp = getOrCreatePane(peer, false);
        if (!contactRows.containsKey(peer)) {
            createContactRow(peer, false);
            contactListPanel.revalidate(); contactListPanel.repaint();
        }
        cp.inputField.setEnabled(true); cp.sendBtn.setEnabled(true);
        addSys(cp, "🔒  E2E session established with " + peer);
        addSys(cp, "🔑  Shared fingerprint: " + fp + "  (both sides identical)");
        // Update FP label if this is the active chat
        if (peer.equals(activeChatKey)) {
            fingerprintLabel.setText("🔑 e2e-fp [" + peer + "]: " + fp);
            fingerprintLabel.setForeground(ACCENT_GREEN);
        }
    }

    // ── CONNECT ───────────────────────────────────────────────────────────────
    private void doConnect() {
        String host = loginHost.getText().trim();
        String portS = loginPort.getText().trim();
        String uname = loginUsername.getText().trim();
        if (host.isEmpty() || portS.isEmpty() || uname.isEmpty()) { loginStatus.setText("Please fill all fields."); return; }
        if (uname.length() > 20) { loginStatus.setText("Username max 20 chars."); return; }
        loginBtn.setEnabled(false); loginStatus.setForeground(ACCENT_GREEN); loginStatus.setText("Connecting...");
        new Thread(() -> {
            try {
                int port = Integer.parseInt(portS); myUsername = uname;
                transportKeyPair = CryptoUtils.generateDHKeyPair();
                socket = new Socket(host, port); socket.setTcpNoDelay(true);
                in  = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));

                // Transport DH handshake
                send("JOIN:" + uname);

                // Server sends its DH pub (raw — before transport is established)
                String pl = in.readUTF();
                if (pl.startsWith("ERR:")) throw new Exception(pl.substring(4));
                if (!pl.startsWith("PUB:")) throw new Exception("Protocol error: expected PUB");
                PublicKey serverPub = CryptoUtils.decodeDHPublicKey(Base64.getDecoder().decode(pl.substring(4)));

                // Send our pub
                send("PUB:" + Base64.getEncoder().encodeToString(
                        CryptoUtils.encodePublicKey(transportKeyPair.getPublic())));

                // Derive transport key
                byte[] shared = CryptoUtils.agreeSharedSecret(transportKeyPair.getPrivate(), serverPub);
                transportKey  = CryptoUtils.deriveAESKey(shared);
                transportFP   = CryptoUtils.shortKeyFingerprint(transportKey);

                SwingUtilities.invokeLater(() -> {
                    rootCards.show(getContentPane(), "main");
                    setTitle("🔐 SecureChat — " + myUsername);
                    topBarName.setText("SecureChat  ·  " + myUsername);
                    topBarStatus.setText("🟢  Connected · Encrypted");
                    fingerprintLabel.setText("🔑 transport-fp: " + transportFP);
                    ChatPane groupPane = createChatPane("GROUP", true);
                    groupPane.inputField.setEnabled(true); groupPane.sendBtn.setEnabled(true);
                    createContactRow("GROUP", true);
                    activeChatKey = "GROUP";
                    contactRows.get("GROUP").panel.setBackground(BG_CONTACT_SEL);
                    rightCards.show(rightArea, "GROUP");
                    addSys(groupPane, "🔒  Transport secured  |  Server fp: " + transportFP);
                    addSys(groupPane, "💡  Open a private chat → E2E DH session auto-starts (same FP both sides)");
                    groupPane.inputField.requestFocus();
                });
                listenLoop();
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    loginStatus.setForeground(new Color(220, 80, 80));
                    loginStatus.setText("Error: " + ex.getMessage());
                    loginBtn.setEnabled(true);
                });
                closeConn();
            }
        }, "Connect").start();
    }

    // ── SEND (transport-encrypted) ─────────────────────────────────────────────
    private void sendEncrypted(String plain) {
        try {
            String enc = CryptoUtils.encryptAESGCM(plain, transportKey);
            send("ENC:" + enc);
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> addSysToActive("❌  Transport encrypt error: " + ex.getMessage()));
        }
    }

    // ── LISTEN LOOP ───────────────────────────────────────────────────────────
    private void listenLoop() {
        try {
            while (!socket.isClosed()) handleLine(in.readUTF());
        } catch (EOFException | SocketException ignored) {
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> addSysToActive("⚠  Error: " + ex.getMessage()));
        } finally {
            SwingUtilities.invokeLater(() -> {
                topBarStatus.setText("🔴  Disconnected");
                for (ChatPane cp : chatPanes.values()) { cp.inputField.setEnabled(false); cp.sendBtn.setEnabled(false); }
                addSysToActive("🔌  Disconnected from server");
            });
        }
    }

    private void handleLine(String line) {
        if (line.startsWith("ENC:")) {
            // Transport-encrypted server message — decrypt first
            String inner;
            try { inner = CryptoUtils.decryptAESGCM(line.substring(4), transportKey); }
            catch (Exception ex) {
                SwingUtilities.invokeLater(() -> addSysToActive("⚠  Transport decrypt error"));
                return;
            }
            handleDecrypted(inner);
        } else if (line.equals("PONG")) {
            // keep-alive reply
        }
        // raw lines before transport established are handled in doConnect()
    }

    private void handleDecrypted(String inner) {
        if (inner.startsWith("MSG:")) {
            // Group broadcast
            String p = inner.substring(4); int s = p.indexOf('|'); if (s < 0) return;
            String from = p.substring(0, s);
            String text = p.substring(s + 1);
            SwingUtilities.invokeLater(() -> {
                ChatPane cp = getOrCreatePane("GROUP", true);
                addBubble(cp, from, text, false, false);
                updateLastMsg(contactRows.get("GROUP"), from + ": " + text);
                if (!"GROUP".equals(activeChatKey)) bumpBadge("GROUP");
            });

        } else if (inner.startsWith("PMSG:")) {
            // Private E2E message — decrypt with C2C key
            String p = inner.substring(5); int s = p.indexOf('|'); if (s < 0) return;
            String from    = p.substring(0, s);
            String payload = p.substring(s + 1);
            C2CSession session = c2cSessions.get(from);
            if (session == null || !session.isReady()) {
                SwingUtilities.invokeLater(() -> addSysToActive("⚠  PM from " + from + " — E2E session not ready yet"));
                return;
            }
            try {
                String text = CryptoUtils.decryptAESGCM(payload, session.e2eKey);
                SwingUtilities.invokeLater(() -> {
                    ChatPane cp = getOrCreatePane(from, false);
                    if (!contactRows.containsKey(from)) {
                        createContactRow(from, false);
                        contactListPanel.revalidate(); contactListPanel.repaint();
                    }
                    addBubble(cp, from, text, false, true);
                    updateLastMsg(contactRows.get(from), from + ": " + text);
                    if (!from.equals(activeChatKey)) bumpBadge(from);
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> addSysToActive("⚠  PM decrypt error from " + from));
            }

        } else if (inner.startsWith("C2C_PUB:")) {
            // Peer's DH public key received via server relay
            String body = inner.substring(8); int s = body.indexOf('|'); if (s < 0) return;
            String from   = body.substring(0, s);
            String pubB64 = body.substring(s + 1);
            // Process off EDT to avoid blocking
            new Thread(() -> onReceivePeerPub(from, pubB64)).start();

        } else if (inner.startsWith("USERS:")) {
            String[] us = inner.substring(6).isEmpty() ? new String[0] : inner.substring(6).split(",");
            SwingUtilities.invokeLater(() -> updateUserList(us));

        } else if (inner.startsWith("JOINED:")) {
            String w = inner.substring(7);
            SwingUtilities.invokeLater(() -> { ChatPane gp = chatPanes.get("GROUP"); if (gp!=null) addSys(gp, "👤  " + w + " joined"); });

        } else if (inner.startsWith("LEFT:")) {
            String w = inner.substring(5);
            // Remove C2C session for disconnected peer
            c2cSessions.remove(w);
            SwingUtilities.invokeLater(() -> { ChatPane gp = chatPanes.get("GROUP"); if (gp!=null) addSys(gp, "👤  " + w + " left"); });

        } else if (inner.startsWith("INFO:")) {
            SwingUtilities.invokeLater(() -> addSysToActive("ℹ  " + inner.substring(5)));

        } else if (inner.startsWith("ERR:")) {
            SwingUtilities.invokeLater(() -> addSysToActive("❌  " + inner.substring(4)));
        }
    }

    // ── SEND MESSAGE ──────────────────────────────────────────────────────────
    private void doSend(ChatPane cp) {
        if (transportKey == null || socket == null || socket.isClosed()) return;
        String text = cp.inputField.getText().trim(); if (text.isEmpty()) return;
        cp.inputField.setText("");

        if (cp.isGroup) {
            // Group: server-mediated (not E2E)
            sendEncrypted("MSG:" + text);
            addBubble(cp, myUsername, text, true, false);
            updateLastMsg(contactRows.get("GROUP"), "You: " + text);
        } else {
            // Private: E2E encrypted with C2C key
            C2CSession session = c2cSessions.get(cp.key);
            if (session == null || !session.isReady()) {
                addSys(cp, "⏳  E2E key exchange in progress — please wait a moment...");
                return;
            }
            try {
                String e2eEnc = CryptoUtils.encryptAESGCM(text, session.e2eKey);
                sendEncrypted("PMSG:" + cp.key + "|" + e2eEnc);
                addBubble(cp, myUsername, text, true, true);
                updateLastMsg(contactRows.get(cp.key), "You: " + text);
            } catch (Exception ex) {
                addSys(cp, "❌  Send error: " + ex.getMessage());
            }
        }
    }

    private void doDisconnect() {
        try { send("BYE"); } catch (Exception ignored) {}
        closeConn();
        SwingUtilities.invokeLater(() -> {
            chatPanes.clear(); contactRows.clear(); c2cSessions.clear();
            contactListPanel.removeAll(); contactListPanel.revalidate(); contactListPanel.repaint();
            rightArea.removeAll();
            JPanel ph = new JPanel(new GridBagLayout()); ph.setBackground(BG_DARK);
            JLabel phl = new JLabel("Select a chat to start messaging");
            phl.setForeground(TEXT_DIM); phl.setFont(FONT_BOLD); ph.add(phl);
            rightArea.add(ph, "_placeholder_");
            rightCards.show(rightArea, "_placeholder_");
            activeChatKey = "GROUP";
            fingerprintLabel.setText("🔑 transport-fp: --------");
            fingerprintLabel.setForeground(TEXT_DIM);
            loginStatus.setText(" "); loginBtn.setEnabled(true);
            rootCards.show(getContentPane(), "login");
        });
    }

    private ChatPane getOrCreatePane(String key, boolean isGroup) {
        ChatPane cp = chatPanes.get(key);
        if (cp == null) {
            cp = createChatPane(key, isGroup);
            if (transportKey != null) { cp.inputField.setEnabled(true); cp.sendBtn.setEnabled(true); }
        }
        return cp;
    }

    private void updateUserList(String[] users) {
        Set<String> current = new HashSet<>(Arrays.asList(users));
        for (String u : users)
            if (!u.isEmpty() && !u.equals(myUsername) && !contactRows.containsKey(u))
                createContactRow(u, false);
        for (Map.Entry<String, ContactRow> e : contactRows.entrySet()) {
            if ("GROUP".equals(e.getKey())) continue;
            e.getValue().nameLabel.setForeground(current.contains(e.getKey()) ? TEXT_MAIN : TEXT_DIM);
        }
        contactListPanel.revalidate(); contactListPanel.repaint();
    }

    private void updateLastMsg(ContactRow cr, String msg) {
        if (cr == null) return;
        cr.lastMsgLabel.setText(msg.length() > 32 ? msg.substring(0, 32) + "…" : msg);
    }

    private void bumpBadge(String key) {
        ContactRow cr = contactRows.get(key); if (cr == null) return;
        cr.unreadCount++;
        cr.badgeLabel.setText(String.valueOf(cr.unreadCount)); cr.badgeLabel.setVisible(true);
    }

    // ── SEARCH ────────────────────────────────────────────────────────────────
    private void toggleSearch(ChatPane cp) {
        boolean vis = !cp.searchBar.isVisible(); cp.searchBar.setVisible(vis);
        if (vis) { cp.searchField.requestFocus(); cp.searchField.selectAll(); }
        else     { clearHL(cp); cp.searchMatches.clear(); cp.searchMatchIndex = -1; }
        cp.searchBar.revalidate(); cp.searchBar.repaint();
    }

    private void doSearch(ChatPane cp) {
        String q = cp.searchField.getText().trim().toLowerCase();
        clearHL(cp); cp.searchMatches.clear(); cp.searchMatchIndex = -1;
        if (q.isEmpty()) { cp.searchResultLabel.setText("  Type to search..."); cp.searchResultLabel.setForeground(TEXT_DIM); return; }
        for (BubbleEntry b : cp.bubbles)
            if (b.text != null && b.text.toLowerCase().contains(q)) cp.searchMatches.add(b);
        if (cp.searchMatches.isEmpty()) {
            cp.searchResultLabel.setText("  No results"); cp.searchResultLabel.setForeground(new Color(220, 80, 80));
        } else {
            cp.searchMatchIndex = cp.searchMatches.size() - 1;
            for (BubbleEntry b : cp.searchMatches) { b.bubble.setBackground(HIGHLIGHT_CLR); b.bubble.repaint(); }
            scrollToBubble(cp, cp.searchMatches.get(cp.searchMatchIndex)); updateSrchLbl(cp);
        }
    }

    private void navSearch(ChatPane cp, int d) {
        if (cp.searchMatches.isEmpty()) return;
        cp.searchMatchIndex = (cp.searchMatchIndex + d + cp.searchMatches.size()) % cp.searchMatches.size();
        scrollToBubble(cp, cp.searchMatches.get(cp.searchMatchIndex)); updateSrchLbl(cp);
    }

    private void clearHL(ChatPane cp) {
        for (BubbleEntry b : cp.searchMatches) { b.bubble.setBackground(b.origBg); b.bubble.repaint(); }
    }

    private void scrollToBubble(ChatPane cp, BubbleEntry b) {
        SwingUtilities.invokeLater(() -> cp.messagesPanel.scrollRectToVisible(b.row.getBounds()));
    }

    private void updateSrchLbl(ChatPane cp) {
        cp.searchResultLabel.setText("  " + (cp.searchMatchIndex + 1) + " / " + cp.searchMatches.size());
        cp.searchResultLabel.setForeground(ACCENT_GREEN);
    }

    // ── EMOJI ─────────────────────────────────────────────────────────────────
    private void showEmoji(ChatPane cp) {
        String[] em = {"😊","😂","❤️","👍","🙏","🔥","😍","🎉","💯","😎",
                       "🥺","😢","😡","🤔","🤩","😴","🙌","✅","🚀","💬"};
        JPopupMenu pop = new JPopupMenu(); pop.setBackground(BG_PANEL);
        pop.setBorder(BorderFactory.createLineBorder(new Color(60, 80, 95), 1));
        JPanel grid = new JPanel(new GridLayout(2, 10, 4, 4));
        grid.setBackground(BG_PANEL); grid.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        for (String s : em) {
            JButton b = new JButton(s); b.setFont(new Font("Segoe UI", Font.PLAIN, 18));
            b.setBackground(new Color(40,55,68)); b.setForeground(TEXT_MAIN);
            b.setFocusPainted(false); b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(ev -> { cp.inputField.setText(cp.inputField.getText()+s);
                cp.inputField.requestFocus(); pop.setVisible(false); });
            grid.add(b);
        }
        pop.add(grid); pop.show(cp.emojiBtn, 0, -pop.getPreferredSize().height - 4);
    }

    // ── BUBBLES ───────────────────────────────────────────────────────────────
    private void addBubble(ChatPane cp, String from, String text, boolean isSelf, boolean isPM) {
        Color bg = isPM ? BG_MSG_PM : (isSelf ? BG_MSG_SELF : BG_MSG_OTHER);
        JPanel row = new JPanel(); row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false); row.setAlignmentX(LEFT_ALIGNMENT);
        row.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        if (isSelf) row.add(Box.createHorizontalGlue());
        JPanel bubble = new JPanel(); bubble.setLayout(new BoxLayout(bubble, BoxLayout.Y_AXIS));
        bubble.setBackground(bg);
        bubble.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(16, isSelf, bg),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));
        if (!isSelf) {
            JLabel nameL = new JLabel(from); nameL.setFont(new Font("Segoe UI", Font.BOLD, 12));
            nameL.setForeground(isPM ? new Color(210,170,255) : ACCENT_BLUE);
            nameL.setAlignmentX(LEFT_ALIGNMENT); bubble.add(nameL); bubble.add(Box.createVerticalStrut(3));
        }
        JTextArea ta = new JTextArea(text); ta.setEditable(false); ta.setOpaque(false);
        ta.setForeground(TEXT_MAIN); ta.setFont(FONT_MSG); ta.setWrapStyleWord(true); ta.setLineWrap(true);
        ta.setFocusable(false); ta.setBorder(null); ta.setAlignmentX(LEFT_ALIGNMENT); ta.setColumns(35);
        bubble.add(ta); bubble.add(Box.createVerticalStrut(4));
        JPanel tr = new JPanel(new BorderLayout()); tr.setOpaque(false); tr.setAlignmentX(LEFT_ALIGNMENT);
        JLabel tl = new JLabel(TIME_FMT.format(new Date())); tl.setFont(FONT_SMALL); tl.setForeground(TEXT_TIME);
        if (isSelf) { JLabel ck = new JLabel("✓✓ "); ck.setFont(FONT_SMALL); ck.setForeground(new Color(79,195,116)); tr.add(ck, BorderLayout.WEST); }
        tr.add(tl, isSelf ? BorderLayout.EAST : BorderLayout.WEST); bubble.add(tr);
        row.add(bubble); if (!isSelf) row.add(Box.createHorizontalGlue());
        bubble.addComponentListener(new ComponentAdapter(){
            public void componentResized(ComponentEvent e){
                int vw = cp.chatScroll.getViewport().getWidth();
                int mw = vw > 100 ? (int)(vw * 0.60) : 460;
                bubble.setMaximumSize(new Dimension(mw, Integer.MAX_VALUE));
                ta.setSize(new Dimension(mw - 28, Short.MAX_VALUE));
            }
        });
        cp.messagesPanel.add(row); cp.messagesPanel.revalidate(); cp.messagesPanel.repaint();
        cp.bubbles.add(new BubbleEntry(row, bubble, from, text, bg));
        scrollToBottom(cp);
    }

    private void addSys(ChatPane cp, String text) {
        if (cp == null) return;
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 4));
        row.setOpaque(false); row.setAlignmentX(LEFT_ALIGNMENT);
        JLabel l = new JLabel(text); l.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        l.setForeground(TEXT_DIM); l.setBackground(new Color(30,42,52)); l.setOpaque(true);
        l.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(45,62,76), 1),
                BorderFactory.createEmptyBorder(3, 14, 3, 14)));
        row.add(l); cp.messagesPanel.add(row); cp.messagesPanel.revalidate();
        scrollToBottom(cp);
    }

    private void addSysToActive(String text) {
        ChatPane cp = chatPanes.get(activeChatKey);
        if (cp == null) cp = chatPanes.get("GROUP");
        addSys(cp, text);
    }

    private void scrollToBottom(ChatPane cp) {
        SwingUtilities.invokeLater(() -> {
            JScrollBar sb = cp.chatScroll.getVerticalScrollBar();
            sb.setValue(sb.getMaximum());
        });
    }

    // ── NET ───────────────────────────────────────────────────────────────────
    private void send(String l) throws IOException { synchronized (out) { out.writeUTF(l); out.flush(); } }

    private void closeConn() {
        try { if (in!=null) in.close(); } catch (IOException ignored) {}
        try { if (out!=null) out.close(); } catch (IOException ignored) {}
        try { if (socket!=null) socket.close(); } catch (IOException ignored) {}
        transportKey = null;
    }

    // ── UI HELPERS ────────────────────────────────────────────────────────────
    private JTextField tf(String d) {
        JTextField f = new JTextField(d); f.setFont(FONT_MSG);
        f.setBackground(BG_INPUT); f.setForeground(TEXT_MAIN); f.setCaretColor(ACCENT_GREEN);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 80, 95), 1),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46)); f.setAlignmentX(LEFT_ALIGNMENT);
        return f;
    }

    private JLabel lbl(String t) {
        JLabel l = new JLabel(t); l.setFont(FONT_SMALL); l.setForeground(TEXT_DIM);
        l.setAlignmentX(LEFT_ALIGNMENT); l.setBorder(BorderFactory.createEmptyBorder(0, 2, 4, 0));
        return l;
    }

    private void styleBtn(JButton b, Color bg, Color fg) {
        b.setBackground(bg); b.setForeground(fg); b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    }

    private JButton mkBtn2(String t) {
        JButton b = new JButton(t); b.setFont(FONT_SMALL);
        b.setBackground(new Color(40,55,68)); b.setForeground(TEXT_MAIN);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        return b;
    }

    static class RoundedBorder extends AbstractBorder {
        private final int radius; private final boolean isSelf; private final Color color;
        RoundedBorder(int r, boolean s, Color c) { radius=r; isSelf=s; color=c; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color); g2.fillRoundRect(x, y, w-1, h-1, radius, radius); g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(radius/2, radius/2, radius/2, radius/2); }
        public boolean isBorderOpaque() { return false; }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new ChatClient().setVisible(true));
    }
}
